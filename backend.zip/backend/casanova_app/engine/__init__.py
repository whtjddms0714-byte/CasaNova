# backend/casanova_app/engine/__init__.py
"""
CasaNova recommendation engine package.
"""
